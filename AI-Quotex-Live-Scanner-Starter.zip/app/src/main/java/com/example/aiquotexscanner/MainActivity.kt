package com.example.aiquotexscanner

import android.app.Activity
import android.content.Context
import android.content.Intent
import android.graphics.PixelFormat
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import android.view.Gravity
import android.view.WindowManager
import android.widget.Button
import android.widget.LinearLayout
import android.widget.TextView

class MainActivity : Activity() {
    private val overlayRequest = 4001

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(28, 36, 28, 28)
            setBackgroundColor(0xFF101827.toInt())
        }

        fun label(text: String, size: Float = 18f): TextView =
            TextView(this).apply {
                this.text = text
                textSize = size
                setTextColor(0xFFFFFFFF.toInt())
                setPadding(0, 12, 0, 12)
            }

        root.addView(label("AI QUOTEX SCANNER", 24f))
        root.addView(label("Starter version: floating panel demo", 16f))
        root.addView(label("The displayed signal is a demo only. It is not live AI analysis.", 14f))

        val overlayButton = Button(this).apply {
            text = "Enable floating window"
            setOnClickListener {
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M && !Settings.canDrawOverlays(this@MainActivity)) {
                    val intent = Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION,
                        Uri.parse("package:$packageName"))
                    startActivityForResult(intent, overlayRequest)
                } else {
                    showOverlay()
                }
            }
        }
        root.addView(overlayButton)

        val closeButton = Button(this).apply {
            text = "Close floating window"
            setOnClickListener { removeOverlay() }
        }
        root.addView(closeButton)

        setContentView(root)
    }

    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode == overlayRequest &&
            (Build.VERSION.SDK_INT < Build.VERSION_CODES.M || Settings.canDrawOverlays(this))) {
            showOverlay()
        }
    }

    private fun showOverlay() {
        val wm = getSystemService(Context.WINDOW_SERVICE) as WindowManager
        if (OverlayHolder.view != null) return

        val panel = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(18, 14, 18, 14)
            setBackgroundColor(0xEE111827.toInt())
        }
        val title = TextView(this).apply {
            text = "AI SCANNER"
            textSize = 16f
            setTextColor(0xFFFFFFFF.toInt())
        }
        val signal = TextView(this).apply {
            text = "SIGNAL: NO TRADE"
            textSize = 18f
            setTextColor(0xFFFFD54F.toInt())
            setPadding(0, 8, 0, 8)
        }
        val confidence = TextView(this).apply {
            text = "Confidence: --"
            textSize = 14f
            setTextColor(0xFFFFFFFF.toInt())
        }
        val scan = Button(this).apply {
            text = "SCAN (DEMO)"
            setOnClickListener {
                signal.text = "SIGNAL: NO TRADE"
                confidence.text = "Confidence: Not calculated"
            }
        }
        val close = Button(this).apply {
            text = "×"
            setOnClickListener { removeOverlay() }
        }
        panel.addView(title)
        panel.addView(signal)
        panel.addView(confidence)
        panel.addView(scan)
        panel.addView(close)

        val type = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O)
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY
        else
            @Suppress("DEPRECATION") WindowManager.LayoutParams.TYPE_PHONE

        val params = WindowManager.LayoutParams(
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.WRAP_CONTENT,
            type,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE,
            PixelFormat.TRANSLUCENT
        ).apply {
            gravity = Gravity.TOP or Gravity.START
            x = 30
            y = 180
        }

        try {
            wm.addView(panel, params)
            OverlayHolder.view = panel
            OverlayHolder.manager = wm
        } catch (_: Exception) {
            // User can return to the app and enable overlay permission again.
        }
    }

    private fun removeOverlay() {
        try {
            OverlayHolder.view?.let { OverlayHolder.manager?.removeView(it) }
        } catch (_: Exception) {
        } finally {
            OverlayHolder.view = null
            OverlayHolder.manager = null
        }
    }

    override fun onDestroy() {
        super.onDestroy()
        // Keep the overlay while the app is backgrounded; remove it with the panel's close button.
    }
}

object OverlayHolder {
    var view: android.view.View? = null
    var manager: WindowManager? = null
}
